import React, { useState, useEffect } from "react";
import { 
  Youtube, 
  Settings, 
  FileText, 
  CheckCircle2, 
  Loader2, 
  ArrowRight, 
  Download,
  BookOpen,
  Camera,
  Cpu,
  Info,
  Layers,
  Zap,
  Activity
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

type ProcessingState = "idle" | "extracting" | "analyzing" | "capturing" | "generating" | "completed" | "error";

interface AnalysisResult {
  taskId: string;
  title: string;
  slideCount: number;
  downloadUrl: string;
}

const MESSAGES = {
  extracting: [
    "Diving into the video stream...",
    "Sampling frames every 10 seconds...",
    "Scanning visuals for transition points...",
    "Waking up the digital eyes..."
  ],
  analyzing: [
    "Calling Gemini 1.5 Flash to identify slide boundaries...",
    "Consulting the AI on which frames are 'clear'...",
    "Detecting whiteboard vs teacher...",
    "Smart grouping of unique content..."
  ],
  capturing: [
    "Snap! Capturing high-res frames for your pdf...",
    "Optimizing image quality...",
    "Ensuring every word is readable...",
  ],
  generating: [
    "Stitching pages into a polished PDF...",
    "Adding slide labels and titles...",
    "Finalizing your study notes..."
  ]
};

const LOGS_POOL = [
  "[INFO] Analyzing timestamp 04:22...",
  "[INFO] Detected occlusion: Teacher blocking board.",
  "[SUCCESS] Frame captured at 04:24 (Clear view).",
  "[INFO] Analyzing timestamp 12:10...",
  "[INFO] Transition detected via Gemini analysis.",
  "[SUCCESS] Slide 4 extracted with 98% confidence.",
];

export default function App() {
  const [url, setUrl] = useState("");
  const [isHuman, setIsHuman] = useState(false);
  const [state, setState] = useState<ProcessingState>("idle");
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [currentMsgIdx, setCurrentMsgIdx] = useState(0);

  const getProgressValue = () => {
    switch(state) {
      case "idle": return 0;
      case "extracting": return 25;
      case "analyzing": return 50;
      case "capturing": return 75;
      case "generating": return 90;
      case "completed": return 100;
      default: return 0;
    }
  };

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (state !== "idle" && state !== "completed" && state !== "error") {
      interval = setInterval(() => {
        setCurrentMsgIdx((prev) => (prev + 1) % 4);
      }, 3000);
    }
    return () => clearInterval(interval);
  }, [state]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return;

    setError(null);
    setResult(null);
    setState("extracting");
    setCurrentMsgIdx(0);

    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url, isHuman }),
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "Failed to process video");
      }

      const data = await response.json();
      setResult(data);
      setState("completed");
    } catch (err: any) {
      setError(err.message || "Something went wrong");
      setState("error");
    }
  };

  const getStatusMessage = () => {
    if (state === "idle" || state === "completed" || state === "error") return "Operational";
    const pool = MESSAGES[state as keyof typeof MESSAGES] || MESSAGES.extracting;
    return pool[currentMsgIdx];
  };

  return (
    <div className="h-screen flex flex-col bg-slate-50 font-sans overflow-hidden text-slate-800">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 px-8 py-4 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="bg-indigo-600 p-2 rounded-lg">
            <Layers className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-xl font-bold text-slate-800 tracking-tight">
            SlideCapture Pro <span className="text-indigo-600 text-xs font-medium ml-2 px-2 py-0.5 bg-indigo-50 rounded-full">AI-V3</span>
          </h1>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 rounded-md">
            <div className={`w-2 h-2 rounded-full ${state === "error" ? "bg-red-500" : state === "idle" ? "bg-emerald-500" : "bg-blue-500 animate-pulse"}`}></div>
            <span className="text-xs font-semibold text-slate-600">
              {state === 'idle' ? 'Processing Server Idle' : state === 'completed' ? 'Processing Complete' : state === 'error' ? 'Analysis Error' : 'Analysis In Progress'}
            </span>
          </div>
          <div className="w-9 h-9 rounded-full bg-slate-200 border border-slate-200 flex items-center justify-center text-xs font-bold text-slate-500">
            AS
          </div>
        </div>
      </header>

      <main className="flex-1 flex overflow-hidden">
        {/* Left Panel: Configuration & Analysis */}
        <aside className="w-[400px] bg-white border-r border-slate-200 p-6 flex flex-col gap-6 overflow-hidden shrink-0">
          <section>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Source YouTube URL</label>
            <form onSubmit={handleSubmit} className="space-y-3">
              <div className="flex gap-2">
                <input 
                  type="text" 
                  placeholder="https://youtube.com/..."
                  className="flex-1 bg-slate-50 border border-slate-200 rounded px-3 py-2 text-sm text-slate-600 focus:ring-1 focus:ring-indigo-50 outline-none"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  disabled={state !== "idle" && state !== "completed" && state !== "error"}
                />
                <button 
                  type="submit"
                  disabled={state !== "idle" && state !== "completed" && state !== "error"}
                  className="bg-slate-800 text-white px-4 py-2 rounded text-sm font-medium hover:bg-slate-700 transition-colors disabled:opacity-50"
                >
                  {state === 'idle' ? 'Fetch' : <Loader2 className="w-4 h-4 animate-spin" />}
                </button>
              </div>
              <div className="flex items-center gap-2 px-1">
                <input 
                  type="checkbox" 
                  id="human-verify"
                  checked={isHuman}
                  onChange={(e) => setIsHuman(e.target.checked)}
                  disabled={state !== "idle" && state !== "completed" && state !== "error"}
                  className="rounded text-indigo-600 accent-indigo-600 cursor-pointer"
                />
                <label htmlFor="human-verify" className="text-xs font-medium text-slate-500 cursor-pointer select-none">
                  I confirm I am not a bot
                </label>
              </div>
            </form>
          </section>

          <section className="space-y-4">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <Zap className="w-4 h-4 text-indigo-500" />
              Extraction Logic
            </h3>
            <div className="space-y-3">
              <div className="flex items-start gap-3 p-3 bg-indigo-50 border border-indigo-100 rounded-lg">
                <input type="checkbox" checked readOnly className="mt-1 rounded text-indigo-600 accent-indigo-600" />
                <div>
                  <p className="text-sm font-semibold text-indigo-900">Optimal Content Window</p>
                  <p className="text-xs text-indigo-700">Wait for teacher to move aside before capturing.</p>
                </div>
              </div>
              <div className="flex items-start gap-3 p-3 border border-slate-100 rounded-lg bg-slate-50">
                <input type="checkbox" checked readOnly className="mt-1 rounded text-slate-400 accent-indigo-600" />
                <div>
                  <p className="text-sm font-semibold text-slate-700">Slide Transition Detection</p>
                  <p className="text-xs text-slate-500">Auto-snap exactly before pixel threshold change.</p>
                </div>
              </div>
              <div className="flex items-start gap-3 p-3 border border-slate-100 rounded-lg opacity-60">
                <input type="checkbox" checked readOnly className="mt-1 rounded text-slate-400 accent-indigo-600" />
                <div>
                  <p className="text-sm font-semibold text-slate-700">Gemini 1.5 Flash Vision</p>
                  <p className="text-xs text-slate-500">Use AI to verify visual consistency of slides.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="mt-auto">
            <div className="bg-slate-900 rounded-xl p-5 text-white">
              <div className="flex justify-between items-center mb-3">
                <span className="text-xs font-medium text-slate-400">Current Progress</span>
                <span className="text-xs font-bold text-indigo-400">{getProgressValue()}%</span>
              </div>
              <div className="w-full bg-slate-700 h-1.5 rounded-full mb-4 overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${getProgressValue()}%` }}
                  className="bg-indigo-500 h-full rounded-full"
                ></motion.div>
              </div>
              <div className="text-[11px] text-slate-400 font-mono h-20 overflow-y-auto custom-scrollbar">
                <AnimatePresence mode="popLayout">
                  <motion.div
                    key={getStatusMessage()}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="mb-1"
                  >
                    {state !== 'idle' && (
                       <>
                        <span className="text-indigo-400 mr-2">[ACTIVE]</span>
                        {getStatusMessage()}
                       </>
                    )}
                  </motion.div>
                </AnimatePresence>
                {state === 'completed' && <div className="text-emerald-400">[SUCCESS] Tasks completed successfully.</div>}
                {error && <div className="text-red-400">[ERROR] {error}</div>}
              </div>
            </div>
          </section>
        </aside>

        {/* Right Panel: Gallery */}
        <div className="flex-1 bg-slate-100 p-8 flex flex-col overflow-y-auto">
          {state === "completed" && result ? (
            <>
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-lg font-bold text-slate-800">Detected Content (PDF Ready)</h2>
                  <p className="text-sm text-slate-500">{result.title}</p>
                </div>
                <a 
                  href={result.downloadUrl}
                  className="flex items-center gap-2 bg-indigo-600 text-white px-6 py-2.5 rounded-lg font-bold shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all"
                >
                  <Download className="w-5 h-5" />
                  Export as PDF
                </a>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {[...Array(Math.min(6, result.slideCount))].map((_, i) => (
                  <div key={i} className="relative aspect-video bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden group">
                    <div className="absolute top-2 left-2 px-2 py-0.5 bg-black/60 backdrop-blur-md text-[10px] text-white rounded font-mono">
                      Timestamp Detected
                    </div>
                    <div className="w-full h-full flex flex-col items-center justify-center bg-slate-200 group-hover:bg-slate-300 transition-colors">
                      <FileText className="w-8 h-8 text-slate-400 mb-2" />
                      <span className="text-xs font-bold text-slate-400">SLIDE SEGMENT {i + 1}</span>
                    </div>
                    <div className="absolute inset-0 bg-indigo-600/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                  </div>
                ))}
                {result.slideCount > 6 && (
                   <div className="relative aspect-video bg-slate-200 rounded-lg border border-dashed border-slate-400 flex flex-col items-center justify-center">
                    <p className="text-xs font-bold text-slate-500">+{result.slideCount - 6} More Slides</p>
                    <p className="text-[10px] text-slate-400 uppercase">Analyzed & Packaged</p>
                  </div>
                )}
              </div>
            </>
          ) : state === "idle" ? (
            <div className="flex-1 flex flex-col items-center justify-center text-center max-w-lg mx-auto">
              <div className="bg-indigo-100 p-6 rounded-full mb-6">
                <BookOpen className="w-12 h-12 text-indigo-600" />
              </div>
              <h2 className="text-2xl font-bold text-slate-800 mb-4">LectureLens Professional</h2>
              <p className="text-slate-500 mb-8 leading-relaxed">
                Enter a YouTube lecture URL on the left to begin automated slide extraction. Our AI identifies clear board moments and skips lecturer occlusions.
              </p>
              <div className="flex gap-4 items-center text-xs text-slate-500">
                <div className="flex items-center gap-1">
                  <Activity className="w-4 h-4 text-emerald-500" />
                  Real-time Analysis
                </div>
                <div className="w-1 h-1 bg-slate-300 rounded-full"></div>
                <div className="flex items-center gap-1">
                  <Zap className="w-4 h-4 text-amber-500" />
                  PDF Export
                </div>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center">
              <div className="w-16 h-16 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin mb-6"></div>
              <h3 className="text-xl font-bold text-slate-800 mb-2 font-mono">SYSTEM_INITIALIZING...</h3>
              <p className="text-slate-500 max-w-sm">
                We are currently streaming and analyzing the lecture content bit by bit.
              </p>
            </div>
          )}

          {/* Bottom Tip / Limits */}
          <div className="mt-8 space-y-4">
            <div className="bg-white border border-slate-200 p-4 rounded-xl flex items-center gap-4">
              <div className="p-2 bg-amber-50 rounded-full shrink-0">
                <Info className="w-5 h-5 text-amber-600" />
              </div>
              <p className="text-[11px] text-slate-600 leading-tight">
                <strong>Optimization Protocol:</strong> We skip segments where the teacher blocks the board to ensure you get clear slide content.
              </p>
            </div>

            <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl">
              <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                <Settings className="w-3 h-3" />
                Compatibility & Limits
              </h4>
              <ul className="text-[10px] text-slate-500 space-y-1.5">
                <li className="flex items-center gap-2">
                  <div className="w-1 h-1 bg-indigo-400 rounded-full"></div>
                  Supports public recorded lectures
                </li>
                <li className="flex items-center gap-2 text-red-400/80">
                  <div className="w-1 h-1 bg-red-400/80 rounded-full"></div>
                  No Live Streams (Ongoing)
                </li>
                <li className="flex items-center gap-2 text-red-400/80">
                   <div className="w-1 h-1 bg-red-400/80 rounded-full"></div>
                  No Age-Restricted content
                </li>
                 <li className="flex items-center gap-2">
                  <div className="w-1 h-1 bg-indigo-400 rounded-full"></div>
                  Max analysis window: 50 keyframes
                </li>
              </ul>
            </div>
          </div>
        </div>
      </main>

      {/* Bottom Status Bar */}
      <footer className="bg-white border-t border-slate-200 px-8 py-2 flex items-center justify-between text-[10px] text-slate-400 uppercase tracking-widest shrink-0">
        <div className="flex gap-6">
          <span className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></div>
            CORE: ENGINE_STABLE
          </span>
          <span>GPU ACCELERATION: ACTIVE</span>
        </div>
        <div className="flex gap-6">
          <span>GEMINI CLASSIFIER: NOMINAL</span>
          <span>BUILD: V3.2.0-STABLE</span>
        </div>
      </footer>
    </div>
  );
}

